/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import Entidades.Libro;
import java.util.Scanner;

/**
 *
 * @author German
 */
public class LibroService {
    
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    
    public void llenadoLibro(Libro l1){
        
        System.out.println("Ingrese ISBN: ");
        l1.isbn = leer.nextInt();
        
        System.out.println("Ingrese titulo del libro: ");
        l1.titulo = leer.next();
        
        System.out.println("Ingrese autor del libro: ");
        l1.autor = leer.next();
        
        System.out.println("Ingrese numero de paginas: ");
        l1.numPaginas = leer.nextInt();
        
     
    }
    
    public void mostrarInfo(Libro l1){
        
        System.out.println(l1);
    }
    
    
}
